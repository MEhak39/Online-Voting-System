<footer class="footer">© 2022 - <span class="d-none d-sm-inline-block">Crafted with <i class="mdi mdi-heart text-primary"></i> by <strong>Disha Chuahan - 20BCE10087,
Krutarth Dubey - 20BCE11056, 
Aditya Sisodia-20BCE11072,
Mehak Taneja - 20BCE11080</strong></span>.</footer>