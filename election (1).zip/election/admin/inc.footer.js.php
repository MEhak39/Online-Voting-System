<!-- END wrapper --><!-- jQuery  --><script src="<?php echo URL_JS;?>jquery.min.js"></script><script src="<?php echo URL_JS;?>bootstrap.bundle.min.js"></script><script src="<?php echo URL_JS;?>metisMenu.min.js"></script><script src="<?php echo URL_JS;?>jquery.slimscroll.js"></script><script src="<?php echo URL_JS;?>waves.min.js"></script><script src="<?php echo URL_PLUG;?>jquery-sparkline/jquery.sparkline.min.js"></script><!--Morris Chart--><script src="<?php echo URL_PLUG;?>morris/morris.min.js"></script><script src="<?php echo URL_PLUG;?>raphael/raphael-min.js"></script><script src="assets/pages/dashboard.js"></script><!-- App js --><script src="<?php echo URL_JS;?>app.js"></script>
<script>
$('.datepicker').datepicker({
    format: 'mm/dd/yyyy',
    startDate: '-3d'
});
</script>