<link rel="shortcut icon" href="<?php echo URL_IMG;?>favicon.png">
<link rel="stylesheet" href="<?php echo URL_PLUG;?>morris/morris.css">
<link href="<?php echo URL_CSS;?>bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo URL_CSS;?>metismenu.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo URL_CSS;?>icons.css" rel="stylesheet" type="text/css">
<link href="<?php echo URL_CSS;?>style.css" rel="stylesheet" type="text/css">
<link href="<?php echo URL_CSS;?>validation.css" rel="stylesheet" type="text/css">
<script>
function deletex()
{
	var r=confirm("Are You Sure You Want To Delete");
if (r==true)
  {
  return true;
  }
else
  {
	return false;
  } 
}
</script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
