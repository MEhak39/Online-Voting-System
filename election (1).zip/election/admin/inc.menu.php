<div class="left side-menu">
  <div class="slimscroll-menu" id="remove-scroll"><!--- Sidemenu -->
    <div id="sidebar-menu"><!-- Left Menu Start -->
      <ul class="metismenu" id="side-menu">
        <li><a href="dashboard.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Dashboard</span></a></li>
        <li><a href="election.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Election </span></a></li>
        <li><a href="candidate.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Candidate </span></a></li>
        <li><a href="voter.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Voters </span></a></li>
        <li><a href="result.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Result </span></a></li>
        <li><a href="settings.php" class="waves-effect"><i class="mdi mdi-album"></i> <span>Settings</span></a></li>
      </ul>
    </div>
    <!-- Sidebar -->
    <div class="clearfix"></div>
  </div>
  <!-- Sidebar -left --></div>
