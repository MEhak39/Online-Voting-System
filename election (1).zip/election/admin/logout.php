<?php
include_once("config.php");

unset($_SESSION[LOGIN_ADMIN]);
@session_destroy();
redirect(URL_ADMIN);
exit();
?>